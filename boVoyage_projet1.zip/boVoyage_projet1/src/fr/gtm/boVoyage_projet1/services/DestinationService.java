package fr.gtm.boVoyage_projet1.services;

import java.util.List;

import fr.gtm.boVoyage_projet1.entites.Destination;
import fr.gtm.boVoyage_projet1.entites.Formule;
import fr.gtm.boVoyage_projet1.persistence.DestinationDAO;
import fr.gtm.boVoyage_projet1.persistence.DestinationMockDAO;

/**
 * Cette classe assure les services proposés par la couche persistance et entité.
 * 
 * @author adminl
 *
 */
public class DestinationService {
	private DestinationDAO destinationDAO = new DestinationMockDAO();
	
	
	public List<Destination> getAllDestinations() {                                         
		return destinationDAO.finAllDestinations() ;
	}
	
	public List<Formule> getFormules (Destination destination){
		return destination.getListeDeFormules();
	}
	
	public Destination getDestinationById (Long id) {
		return destinationDAO.findDestinationById(id);
	}
	
	public Formule getFormuleById (Long id) {
		return destinationDAO.findFormuleById(id);
		
	}
		
}
