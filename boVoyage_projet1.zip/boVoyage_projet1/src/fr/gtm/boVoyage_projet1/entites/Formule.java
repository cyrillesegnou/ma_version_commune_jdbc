package fr.gtm.boVoyage_projet1.entites;

import java.time.LocalDate;

public class Formule {

	private LocalDate aller;                                                                                                                                                                                                                                           ;
	private LocalDate retour;
	private double prix;
	private int nbPlaces;
	private String description;
	private Long idFormule;
	
	public Formule () {}
			
	public Formule(int nbPlaces, String description) {
		this.nbPlaces = nbPlaces;
		this.description = description;
	}
	public LocalDate getAller() {
		return aller;
	}
	public LocalDate getRetour() {
		return retour;
	}
	/**
	 * cette méthode sert à verifier si la date d'aller est bien avant la date de retour
	 * on a alors une exception si la date d'aller est après la date de retour
	 * @param aller
	 * @throws Exception when aller is after retour
	 */
	public void setAller(LocalDate aller) throws Exception {
		if (null == this.retour || aller.isBefore(retour) ){
			this.aller = aller;
		} else {
			throw new Exception("le date d'aller doit "
					+ "être avant la date de retour");
		}
	}
	/**
	 * cette méthode sert à verifier si la date de retour est après la date d'aller<br>
	 * on a alors une exception si la date de retour est avant la date d'aller<br>
	 * @param retour
	 * @throws Exception when retour is before aller
	 */
	public void setRetour(LocalDate retour) throws Exception {
		if (null == aller || retour.isAfter(aller)) {
		this.retour = retour;
	}else {
		throw new Exception("la date de retour doit"
				+ " être après la date d'aller");
	}
	}  
	public double getPrix() {
		return prix;
	}
	
	/**
	 * cette méthode sert à verifier si le prix est supérieur ou égal à 0<br>
	 * on a une exception si le prix est négatif
	 * @param prix
	 * @throws Exception when price is negative
	 */
	public void setPrix(double prix) throws Exception {
		if (prix >=0) {
		this.prix = prix;
	}else {
		throw new Exception("Le prix ne doit pas être négatif");
	}
	}
	public int getNbPlaces() {
		return nbPlaces;
	}
	public void setNbPlaces(int nbPlaces) {
		this.nbPlaces = nbPlaces;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getIdFormule() {
		return idFormule;
	}
	public void setIdFormule(Long idFormule) {
		this.idFormule = idFormule;
	}
	
	
}
