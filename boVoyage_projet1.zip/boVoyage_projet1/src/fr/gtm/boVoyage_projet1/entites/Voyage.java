package fr.gtm.boVoyage_projet1.entites;

public class Voyage {
	private String region ;
	private String description;
	private Long idVoyage;
	private Voyageur [] tabVoyageurs = new Voyageur[9];
	
	public Voyage () {}

		public Voyage(String region, String description) {
		this.region = region;
		this.description = description;
	}


	public double getPrix() {
		Formule prix = new Formule();
		return prix.getPrix();
		
	}
	
	public Voyageur[] getTabVoyageurs() {
		return tabVoyageurs;
	}

	public void setTabVoyageurs(Voyageur[] tabVoyageurs) {
		this.tabVoyageurs = tabVoyageurs;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getIdVoyage() {
		return idVoyage;
	}
	public void setIdVoyage(Long idVoyage) {
		this.idVoyage = idVoyage;
	}
		

}
