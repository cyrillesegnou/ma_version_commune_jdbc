package fr.gtm.boVoyage_projet1.entites;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Voyageur {
	private String civilite ;
	private String nom;
	private String prenom;
	private String numero;
	private LocalDate date ;
	private Long idVoyageur;
	private List<Voyage> listeDeVoyagesParVoyageur = new ArrayList<>();
	
	public Voyageur () {}
	
	public Voyageur(String civilite, String prenom, String numero, LocalDate date) {
		this.civilite = civilite;
		this.prenom = prenom;
		this.numero = numero;
		this.date = date;
	}

	public List<Voyage> getListeDeVoyagesParVoyageur() {
		return listeDeVoyagesParVoyageur;
	}

	public void setListeDeVoyagesParVoyageur(List<Voyage> listeDeVoyagesParVoyageur) {
		this.listeDeVoyagesParVoyageur = listeDeVoyagesParVoyageur;
	}

	public String getCivilite() {
		return civilite;
	}
	public void setCivilite(String civilite) {
		this.civilite = civilite;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public Long getIdVoyageur() {
		return idVoyageur;
	}
	public void setIdVoyageur(Long idVoyageur) {
		this.idVoyageur = idVoyageur;
	}
	

}
