package fr.gtm.boVoyage_projet1.entites;

import java.util.ArrayList;
import java.util.List;


public class Destination {

	private String nom;
	private String description;
	private Long idDestination;
	private List<Formule> listeDeFormules = new ArrayList<>();
	private List <String> images =new ArrayList<>();
	
	public Destination() {}
	
	
	public Destination(String nom, String description) {
		this.nom = nom;
		this.description = description;
	}
	
	public List<Formule> getListeDeFormules() {
		return listeDeFormules;
	}

	public void setListeDeFormules(List<Formule> listeDeFormules) {
		this.listeDeFormules = listeDeFormules;
	}

	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	public Long getIdDestination() {
		return idDestination;
	}
	
	public void setIdDestination(Long idDestination) {
		this.idDestination = idDestination;
	}
	public List<String> getImages() {
		return images;
	}

	public void setImages(List<String> images) {
		this.images = images;
	}
	
	
}
