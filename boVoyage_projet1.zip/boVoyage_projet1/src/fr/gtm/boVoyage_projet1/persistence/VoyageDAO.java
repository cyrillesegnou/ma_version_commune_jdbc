package fr.gtm.boVoyage_projet1.persistence;

import java.util.List;

import fr.gtm.boVoyage_projet1.entites.Client;
import fr.gtm.boVoyage_projet1.entites.Voyage;
import fr.gtm.boVoyage_projet1.entites.Voyageur;
/**
 * Cette interface contient les méthodes CRUD et des fonctions pour chercher  tous les voyages 
 * les voyages par client et les voyages par voyageurs, ainsi que les voyages par identifiants. 
 * 
 * @author Amal et Cyrille
 *
 */
public interface VoyageDAO {
	
	Voyage create (Voyage voyage) ;
	void delete (Voyage voyage);
	void update (Voyage voyage);
	Voyage findVoyageById (Long idVoyage);
	List<Voyage> findVoyageByClient (Client client);
	List<Voyage> findVoyageByVoyageur (Voyageur voyageur);
	List<Voyage> findAllVoyage(); 
	
}
