package fr.gtm.boVoyage_projet1.persistence;

import java.util.ArrayList;
import java.util.List;

import fr.gtm.boVoyage_projet1.entites.Client;
import fr.gtm.boVoyage_projet1.entites.Voyage;
import fr.gtm.boVoyage_projet1.entites.Voyageur;

/**
 * Cette classe implémente l'interface VoyageDAO contenant les methodes de cette interface.
 * 
 * @author Amal et Cyrille
 *
 */

public class VoyageMockDAO implements VoyageDAO{
	private List <Voyage> listDeVoyage = new ArrayList <Voyage>();
	private static long idVoyage = 0;
	
	
	@Override
	public Voyage create(Voyage voyage) {
		voyage.setIdVoyage(++idVoyage);
		listDeVoyage.add(voyage);
		
		return voyage ;
	}

	@Override
	public void delete(Voyage voyage) {
		listDeVoyage.remove(voyage);

	}

	/**
	 * méthode de mise à jour du voyage 
	 * break quand l'id de voyage est trouvé
	 */
	@Override
	public void update(Voyage voyage) {
		for (int i = 0; i<listDeVoyage.size();i++) {
			if (listDeVoyage.get(i).getIdVoyage()== voyage.getIdVoyage()) {
				updateVoyage(listDeVoyage.get(i), voyage);
				break;
			}
		}
	}
/** 
 * méthode privée de mise à jour de voyage utilisée dans la méthode update
 * @param old
 * @param updated
 */
	private void updateVoyage (Voyage old, Voyage updated) {
		old.setDescription(updated.getDescription());
		old.setTabVoyageurs(updated.getTabVoyageurs());;
		old.setRegion(updated.getRegion());
	}
	
	/**
	 * méthode pour chercher le voyage avec son identifiant
	 * return if voyage founded
	 * return null if voyage not founded
	 */
	
	@Override
	public Voyage findVoyageById(Long idVoyage) {
		for (int i = 0; i<listDeVoyage.size(); i++) {
			if (listDeVoyage.get(i).getIdVoyage() == idVoyage) {
				return listDeVoyage.get(i);
			}
		}
			return null ;
	}
	@Override
	public List<Voyage> findVoyageByClient(Client client) {
		return client.getListDeVoyages();
	}

	@Override
	public List<Voyage> findVoyageByVoyageur(Voyageur voyageur) {
		return voyageur.getListeDeVoyagesParVoyageur();
	}

	@Override
	public List<Voyage> findAllVoyage() {
		return listDeVoyage;
	}

}
