package fr.gtm.boVoyage_projet1.persistence;

import java.util.List;

import fr.gtm.boVoyage_projet1.entites.Destination;
import fr.gtm.boVoyage_projet1.entites.Formule;


/**
 * Cette interface contient les méthodes CRUD et des fonction pour chercher  toutes les destinations 
 * et les formules et les destinations avec leurs identifiants
 * 
 * @author Amal et Cyrille
 *
 */
public interface DestinationDAO {

	Destination create (Destination destination);
	void delete (Destination destination);
	void update (Destination destination);
	Destination findDestinationById (Long idDestination);
	Formule findFormuleById (Long idFormule);
	List<Destination> finAllDestinations();
	
	
	
}
