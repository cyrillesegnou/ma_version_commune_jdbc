package fr.gtm.boVoyage_projet1.persistence;

import java.util.ArrayList;
import java.util.List;

import fr.gtm.boVoyage_projet1.entites.Destination;
import fr.gtm.boVoyage_projet1.entites.Formule;

/**
 * Cette classe implémente l'interface DestinationDAO contenant les methodes de cette interface.
 * 
 * @author Amal et Cyrille
 *
 */
public class DestinationMockDAO implements DestinationDAO{

	private List<Destination> listeDedestinations = new ArrayList<>();
	private List<Formule> listeDeFormules = new ArrayList<>();
	private static long idDestination = 0;
	
	
	@Override
	public void delete(Destination destination) {
		listeDedestinations.remove(destination);	
	}
	
	@Override
	public Destination create(Destination destination) {
		destination.setIdDestination(++idDestination);
		listeDedestinations.add(destination);
		return destination;
	}
	
	
	@Override
	public void update(Destination destination) {
		for (int i=0; i<listeDedestinations.size();i++) {
			if(listeDedestinations.get(i).getIdDestination()== destination.getIdDestination()) {
				updateDestination(listeDedestinations.get(i), destination);
				break;
			}
		}
	}
	private void updateDestination(Destination old, Destination updated) {
		old.setDescription(updated.getDescription());
		old.setImages(updated.getImages());
		old.setListeDeFormules(updated.getListeDeFormules());
		old.setNom(updated.getNom());
	}
	@Override
	public Destination findDestinationById(Long idDestination) {
		for (int i =0;i<listeDedestinations.size();i++) {
			if(listeDedestinations.get(i).getIdDestination()== idDestination) {
				return listeDedestinations.get(i);
			}
		}
		return null;
	}
	
	@Override
	public Formule findFormuleById(Long idFormule) {
		Formule formuleById = null;
		for(int j=0;j<listeDeFormules.size();j++) {
			if (listeDeFormules.get(j).getIdFormule() == idFormule) {
				formuleById = listeDeFormules.get(j);
				break;
			}
		}
		return formuleById;
	}
	  
	@Override
	public List<Destination> finAllDestinations() {
		return listeDedestinations;
	}
	
}
	

	
