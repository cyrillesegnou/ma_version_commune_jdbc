package fr.gtm.boVoyage_projet1.services.tests;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import fr.gtm.boVoyage_projet1.entites.Destination;
import fr.gtm.boVoyage_projet1.entites.Formule;
import fr.gtm.boVoyage_projet1.persistence.DestinationMockDAO;
import fr.gtm.boVoyage_projet1.services.DestinationService;

public class DestinationServiceTest {

	@Test
	public void testGetAllDestinations() {
		Destination destination1 = new Destination();
		Destination destination2 = new Destination();
		DestinationMockDAO destinationMockDAO =new DestinationMockDAO();
		destinationMockDAO.create(destination1);
		destinationMockDAO.create(destination2);
		DestinationService destinationService = new DestinationService();
		List<Destination> destinations= destinationService.getAllDestinations();
		assertEquals(2, destinations.size());
	}

	@Test
	public void testGetFormules() {
		DestinationMockDAO formuleMockDAO =new DestinationMockDAO();
		Destination destination =new Destination();
		                                                       
	}

	@Test
	public void testGetDestinationById() {
		Destination destination1 = new Destination();
		DestinationMockDAO destinationMockDAO =new DestinationMockDAO();
		Destination savedDestination= destinationMockDAO.create(destination1);
		DestinationService destinationService = new DestinationService();
		Destination found = destinationService.getDestinationById(savedDestination.getIdDestination());
		assertEquals(savedDestination.getDescription(), found.getDescription());
		assertEquals(savedDestination.getImages(), found.getImages());
		assertEquals(savedDestination.getListeDeFormules(), found.getListeDeFormules());
		assertEquals(savedDestination.getNom(), found.getNom());
	}

	@Test
	public void testGetFormuleById() {
		Formule formule =new Formule();
		DestinationMockDAO destinationMockDAO =new DestinationMockDAO();
	}

}
