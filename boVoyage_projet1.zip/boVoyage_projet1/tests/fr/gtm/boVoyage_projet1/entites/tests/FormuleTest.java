package fr.gtm.boVoyage_projet1.entites.tests;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Test;

import fr.gtm.boVoyage_projet1.entites.Formule;

public class FormuleTest {
	
	Formule formule = new Formule( 8,"all inclusive");

	@Test
	public void testGetNbPlaces () {
		assertEquals(8, formule.getNbPlaces());
		
	}
	@Test
	public void testGetDescription() {
		assertEquals("all inclusive", formule.getDescription());
	}
	
	@Test
	public void testGetPrix() throws Exception {
		Formule prix = new Formule();
		prix.setPrix(250.0);
		assertEquals(250.0, prix.getPrix(), 0.0001);
	}

	@Test
	public void testGetAller() throws Exception {
		Formule dateAller =new Formule();
		dateAller.setAller(LocalDate.parse("2020-06-12"));
		assertEquals(LocalDate.parse("2020-06-12"), dateAller.getAller());
	}
	
	@Test
	public void testGetRetour() throws Exception {
		Formule dateRetour =new Formule();
		dateRetour.setRetour(LocalDate.parse("2020-06-24"));
		assertEquals(LocalDate.parse("2020-06-24"), dateRetour.getRetour());
	}
	
}
