package fr.gtm.boVoyage_projet1.entites.tests;

import static org.junit.Assert.*;

import org.junit.Test;

import fr.gtm.boVoyage_projet1.entites.Destination;
import fr.gtm.boVoyage_projet1.persistence.DestinationMockDAO;

public class DestinationTest {

	Destination destination = new Destination ("Milan", "ville d'Italie");
	
	@Test
	public void testGetNom () {
		assertEquals("Milan", destination.getNom());		
	}
	@Test
	public void testGetDescription () {
		assertEquals("ville d'Italie", destination.getDescription());		
	}
	
		@Test
	public void testSetNomDestination() {
		destination.setNom("Paris");
		assertEquals("Paris",destination.getNom());
	}
	@Test
	public void testSetDescription() {
		destination.setDescription("Un beau pays");
		assertEquals("Un beau pays", destination.getDescription());
}
	@Test
	public void testGetIdDestination() {
		Destination destination1= new Destination();
		Destination destination2=new Destination();
		DestinationMockDAO destinationMockDAO = new DestinationMockDAO();	
		Destination destinationCreated2 = destinationMockDAO.create(destination2);
		Destination destinationCreated1 = destinationMockDAO.create(destination1);
		assertEquals(destination1.getIdDestination(), destinationCreated1.getIdDestination());
		assertNotEquals(destinationCreated1.getIdDestination(), destinationCreated2.getIdDestination());
	}
	@Test
	public void testGetListeDeFormules() {
		Destination listeDeFormules= new Destination();
		assertNotNull(listeDeFormules.getListeDeFormules());
      }
	@Test
	public void testGetListeDImages() {
		Destination listeDImages= new Destination();
		assertNotNull(listeDImages.getImages());
      }
}