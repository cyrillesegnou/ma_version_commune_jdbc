package fr.gtm.boVoyage_projet1.entites.tests;

import static org.junit.Assert.*;

import org.junit.Test;
import fr.gtm.boVoyage_projet1.entites.Voyage;
import fr.gtm.boVoyage_projet1.persistence.VoyageMockDAO;

public class VoyageTest {
	
	Voyage voyage = new Voyage ("Marseille", "ville cotière");

	@Test
	public void testGetTabVoyageurs() {
		Voyage TabVoyageurs = new Voyage ();
		assertNotNull(TabVoyageurs.getTabVoyageurs());
			}

	@Test
	public void testSetRegion() {
		voyage.setRegion("Ile-De-France");
		assertEquals("Ile-De-France" , voyage.getRegion());
	}

	@Test
	public void testSetDescription() {
		voyage.setDescription("Capitale de la France");
		assertEquals("Capitale de la France", voyage.getDescription());
	}
	@Test
	public void testGetRegion () {
		assertEquals("Marseille", voyage.getRegion());
		
	}
	@Test
	public void testGetDescription () {
		assertEquals("ville cotière", voyage.getDescription());
	}

	@Test
	public void testGetIdVoyage() {
		Voyage voyage1 = new Voyage();
		Voyage voyage2 = new Voyage();
		VoyageMockDAO voyageMockDAO = new VoyageMockDAO();
		Voyage voyageCreated1 = voyageMockDAO.create(voyage1);
		Voyage voyageCreated2 = voyageMockDAO.create(voyage2);
		assertEquals(voyage1.getIdVoyage(), voyageCreated1.getIdVoyage());
		assertNotEquals(voyageCreated1.getIdVoyage(), voyageCreated2.getIdVoyage());	
		
	}

}
