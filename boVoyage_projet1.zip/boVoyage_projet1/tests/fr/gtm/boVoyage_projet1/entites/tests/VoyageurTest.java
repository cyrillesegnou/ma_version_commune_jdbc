package fr.gtm.boVoyage_projet1.entites.tests;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Test;

import fr.gtm.boVoyage_projet1.entites.Voyageur;

public class VoyageurTest {
	
	Voyageur voyageur = new Voyageur ("M", "Sebastien", "125", LocalDate.parse("2020-12-13"));

	@Test
	public void testGetListeDeVoyagesParVoyageur() {
		Voyageur ListeDeVoyageur = new Voyageur();
		assertNotNull (ListeDeVoyageur.getListeDeVoyagesParVoyageur());
	}
	@Test
	public void testGetCivilite() {
		assertEquals("M", voyageur.getCivilite());		
	}

	@Test
	public void testSetCivilite() {
		voyageur.setCivilite("Mme");
		assertEquals ("Mme", voyageur.getCivilite());
	}

	@Test
	public void testGetPrenom() {
		assertEquals("Sebastien", voyageur.getPrenom());
	}

	@Test
	public void testSetPrenom() {
		voyageur.setPrenom("Henri");
		assertEquals ("Henri", voyageur.getPrenom());
	}

	@Test
	public void testGetNumero() {
		assertEquals("125", voyageur.getNumero());
			}

	@Test
	public void testSetNumero() {
		voyageur.setNumero("351");
		assertEquals("351", voyageur.getNumero());
	}

	@Test
	public void testGetDate() {
		assertEquals(LocalDate.parse("2020-12-13"), voyageur.getDate());
	}

	@Test
	public void testSetDate() {
		voyageur.setDate(LocalDate.parse("2020-06-06"));
		assertEquals(LocalDate.parse("2020-06-06"), voyageur.getDate());
	}


}
