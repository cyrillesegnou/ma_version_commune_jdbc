package fr.gtm.boVoyage_projet1.entites.tests;

import static org.junit.Assert.*;

import org.junit.Test;

import fr.gtm.boVoyage_projet1.entites.Client;

public class ClientTest {

	private Client client = new Client("titi","123");
	
	@Test
	public void testGetNom() {
		assertEquals(client.getNom(), "titi");
	}
	@Test
	public void testGetNumero () {
		assertEquals ("123", client.getNumero());
				
	}
	@Test
	public void testGetListDeVoyages (){
		Client listeDeVoyages = new Client();
		assertNotNull(listeDeVoyages.getListDeVoyages());
	}
	
	@Test
	public void testSetNom() {
		client.setNom("toto");
		assertEquals("toto", client.getNom());
	}
}