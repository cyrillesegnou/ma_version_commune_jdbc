package fr.gtm.boVoyage_projet1.persistence.tests;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import fr.gtm.boVoyage_projet1.entites.Destination;
import fr.gtm.boVoyage_projet1.persistence.DestinationMockDAO;


public class DestinationMockDAOTest {

	/**
	 * test de la méthode delete : <br>
	 * création de la destination puis verification de la suppression 
	 */
	@Test
	public void testDelete() {
		Destination destination =new Destination();
		DestinationMockDAO destinationMockDAO = new DestinationMockDAO();
		destination = destinationMockDAO.create(destination);
		destinationMockDAO.delete(destination);
		assertEquals(0, destinationMockDAO.finAllDestinations().size());
	}

	@Test
	public void testCreate() {
		Destination destination =new Destination();
		DestinationMockDAO destinationMockDAO = new DestinationMockDAO();
		Destination created= destinationMockDAO.create(destination);
		assertEquals(destination.getDescription(), created.getDescription());
		assertEquals(destination.getImages(), created.getImages());
		assertEquals(destination.getListeDeFormules(), created.getListeDeFormules());
		assertEquals(destination.getNom(), created.getNom());	
	}

	@Test
	public void testUpdate() {
		Destination destination =new Destination();
		DestinationMockDAO destinationMockDAO = new DestinationMockDAO();
		Destination created= destinationMockDAO.create(destination);
		created.setNom("Paris");
		destinationMockDAO.update(created);
		Destination updated = destinationMockDAO.findDestinationById(created.getIdDestination());
		assertEquals(created.getDescription(), updated.getDescription());
		assertEquals(created.getImages(), updated.getImages());
		assertEquals(created.getListeDeFormules(), updated.getListeDeFormules());
		assertEquals(created.getNom(), updated.getNom());	
	}

	@Test
	public void testFindDestinationById() {
		Destination destination1 = new Destination();
		DestinationMockDAO destinationMockDAO =new DestinationMockDAO();
		Destination savedDestination= destinationMockDAO.create(destination1);
		Destination found = destinationMockDAO.findDestinationById(savedDestination.getIdDestination());
		assertEquals(savedDestination.getDescription(), found.getDescription());
		assertEquals(savedDestination.getImages(), found.getImages());
		assertEquals(savedDestination.getListeDeFormules(), found.getListeDeFormules());
		assertEquals(savedDestination.getNom(), found.getNom());
	}

	@Test
	public void testFindFormuleById() {
		
	}

	@Test
	public void testFinAllDestinations() {
		Destination destination1 = new Destination();
		Destination destination2 = new Destination();
		DestinationMockDAO destinationMockDAO =new DestinationMockDAO();
		destinationMockDAO.create(destination1);
		destinationMockDAO.create(destination2);
		List<Destination> destinations= destinationMockDAO.finAllDestinations();
		assertEquals(2, destinations.size());
	}

}
