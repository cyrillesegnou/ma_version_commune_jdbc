package fr.gtm.boVoyage_projet1.persistence.tests;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import fr.gtm.boVoyage_projet1.entites.Client;
import fr.gtm.boVoyage_projet1.entites.Voyage;
import fr.gtm.boVoyage_projet1.entites.Voyageur;
import fr.gtm.boVoyage_projet1.persistence.VoyageMockDAO;

public class VoyageMockDAOTest {

	@Test
	public void testCreate() {
		Voyage voyage = new Voyage ();
		VoyageMockDAO voyageMockDAO = new VoyageMockDAO ();
		Voyage voyageCreated = voyageMockDAO.create(voyage);
		assertEquals(voyage.getRegion(), voyageCreated.getRegion());
		assertEquals(voyage.getDescription(), voyageCreated.getDescription());
		assertArrayEquals(voyage.getTabVoyageurs(), voyage.getTabVoyageurs());
		assertEquals(voyage.getPrix(), voyage.getPrix(), 0.0001);
		
	}

	@Test
	public void testDelete() {
		Voyage voyage = new Voyage();
		VoyageMockDAO voyageMockDAO = new VoyageMockDAO ();
		voyage = voyageMockDAO.create(voyage);
		voyageMockDAO.delete(voyage);
		assertEquals(0, voyageMockDAO.findAllVoyage().size());
	}

	@Test
	public void testUpdate() {
		Voyage voyage = new Voyage ();
		VoyageMockDAO voyageMockDAO = new VoyageMockDAO ();
		Voyage voyageCreated = voyageMockDAO.create(voyage);
		voyageCreated.setRegion("Paris");	
		voyageMockDAO.update(voyageCreated);
		Voyage voyageUpdated = voyageMockDAO.findVoyageById(voyageCreated.getIdVoyage());
		assertEquals(voyageCreated.getDescription(), voyageUpdated.getDescription());
		assertEquals(voyageCreated.getRegion(), voyageUpdated.getRegion());
		assertArrayEquals(voyageCreated.getTabVoyageurs(), voyageUpdated.getTabVoyageurs());
		assertEquals(voyageCreated.getPrix(), voyageUpdated.getPrix(), 0.0001);
		
	}

	@Test
	public void testFindVoyageById() {
		Voyage voyage = new Voyage();
		VoyageMockDAO voyageMockDAO = new VoyageMockDAO ();
		Voyage voyageSaved =voyageMockDAO.create(voyage);
		Voyage voyageFounded=voyageMockDAO.findVoyageById(voyageSaved.getIdVoyage());
		assertEquals (voyageSaved.getDescription(), voyageFounded.getDescription());
		assertEquals (voyageSaved.getRegion(), voyageFounded.getRegion());
		assertEquals (voyageSaved.getPrix(), voyageFounded.getPrix(), 0.0001);
		assertArrayEquals (voyageSaved.getTabVoyageurs(), voyageFounded.getTabVoyageurs());
				
	}

	@Test
	public void testFindVoyageByClient() {
		Voyage voyage = new Voyage();
		Client client = new Client();
		VoyageMockDAO voyageMockDAO = new VoyageMockDAO ();
		Voyage voyageCreated = voyageMockDAO.create(voyage);
		List<Voyage> voyageByClient= voyageMockDAO.findVoyageByClient(client);
		assertNotNull(voyageByClient.size());
		boolean voyageAded= voyageByClient.add(voyageCreated);
		assertTrue(voyageAded);
		
		
	}

	@Test
	public void testFindVoyageByVoyageur() {
		Voyageur voyageur=new Voyageur();
		Voyage voyage=new Voyage();
		VoyageMockDAO voyageMockDAO = new VoyageMockDAO ();
		Voyage voyageCreated = voyageMockDAO.create(voyage);
		List<Voyage> voyageByVoyageur = voyageMockDAO.findVoyageByVoyageur(voyageur);
		assertNotNull(voyageByVoyageur.size());
		boolean voyageAded= voyageByVoyageur.add(voyageCreated);
		assertTrue(voyageAded);
	}

}
